import React from 'react';
import { Github, Linkedin, Code2, Mail } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="pt-20 min-h-screen flex items-center bg-gradient-to-br from-blue-50 to-gray-100">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2 text-center md:text-left">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4">
              Hi, I'm Kanishik Sai Koshik
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8">
              Full Stack MERN Developer | AI Enthusiast
            </p>
            <div className="flex space-x-4 justify-center md:justify-start mb-8">
              <a
                href="https://github.com/kanishik0011"
                className="p-2 bg-gray-900 text-white rounded-full hover:bg-gray-700 transition-colors"
              >
                <Github size={24} />
              </a>
              <a
                href="https://www.linkedin.com/in/kanishk-sai-kaushik6a6945272/"
                className="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
              >
                <Linkedin size={24} />
              </a>
              <a
                href="https://leetcode.com/u/kanishkkaushik78/"
                className="p-2 bg-yellow-500 text-white rounded-full hover:bg-yellow-600 transition-colors"
              >
                <Code2 size={24} />
              </a>
              <a
                href="mailto:kanishkkaushik78@gmail.com"
                className="p-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
              >
                <Mail size={24} />
              </a>
            </div>
            <a
              href="#contact"
              className="inline-block bg-blue-600 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Get in Touch
            </a>
          </div>
          <div className="md:w-1/2 mt-12 md:mt-0">
            <img
              src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80"
              alt="Developer workspace"
              className="rounded-lg shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;