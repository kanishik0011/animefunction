import React from 'react';

const projects = [
  {
    title: "AI-Based Gender Recognition System",
    description: "Developed a Python-based gender recognition system using OpenCV and deep learning models, capable of identifying gender from webcam input in real time. Integrated AI with computer vision to provide smart surveillance solutions.",
    tech: ["Python", "OpenCV", "TensorFlow", "NumPy"],
    image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "E-commerce Website",
    description: "Designed and deployed a full-featured e-commerce web application with user authentication, product listings, shopping cart, payment integration, and admin dashboard.",
    tech: ["MongoDB", "Express.js", "React.js", "Node.js", "Redux", "Stripe API"],
    image: "https://images.unsplash.com/photo-1557821552-17105176677c?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "Tele AI-based Healthcare Platform",
    description: "Built a telehealth system featuring virtual check-ups, AI chatbot, and video consultations using React and Node.js.",
    tech: ["React.js", "Node.js", "JavaScript", "MongoDB"],
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "Smart AI-based Traffic System",
    description: "Developed a camera-integrated traffic management tool that uses DSA algorithms and Python scripting to manage signals based on vehicle density.",
    tech: ["Python", "OpenCV", "Data Structures"],
    image: "https://images.unsplash.com/photo-1494522855154-9297ac14b55f?auto=format&fit=crop&w=800&q=80"
  }
];

const Projects = () => {
  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300">
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3">{project.title}</h3>
                <p className="text-gray-600 mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tech.map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-sm"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;