import React from 'react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">About Me</h2>
        <div className="max-w-3xl mx-auto">
          <p className="text-lg text-gray-700 mb-6">
            I'm a passionate Full Stack MERN Developer with a strong foundation in web development,
            AI integration, and system design. Currently pursuing my Bachelor of Technology in
            Computer Science and Business System at GYAN GANGA INSTITUTE OF TECHNOLOGY AND SCIENCE
            with a CGPA of 7.51.
          </p>
          <p className="text-lg text-gray-700 mb-6">
            I specialize in building scalable, responsive, and user-centric web applications,
            with a particular interest in AI-enabled solutions. My experience spans from developing
            real-time gender recognition systems to creating full-featured e-commerce platforms.
          </p>
          <div className="bg-blue-50 p-6 rounded-lg">
            <h3 className="text-xl font-semibold mb-4">Education</h3>
            <div>
              <h4 className="font-semibold">GYAN GANGA INSTITUTE OF TECHNOLOGY AND SCIENCE (GGITS)</h4>
              <p className="text-gray-600">Bachelor of Technology in Computer Science and Business System</p>
              <p className="text-gray-600">2022 – 2026</p>
              <p className="text-gray-600">CGPA: 7.51</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;