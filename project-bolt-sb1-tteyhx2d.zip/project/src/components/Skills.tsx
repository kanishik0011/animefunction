import React from 'react';

const skillCategories = [
  {
    title: "Languages",
    skills: ["JavaScript", "Python", "C++", "Java"]
  },
  {
    title: "Web Technologies",
    skills: ["HTML", "CSS", "JavaScript", "React.js", "Node.js", "Express.js", "Redux"]
  },
  {
    title: "Databases",
    skills: ["MongoDB", "SQL"]
  },
  {
    title: "AI/ML Tools",
    skills: ["OpenCV", "TensorFlow"]
  },
  {
    title: "Others",
    skills: ["Git", "GitHub", "REST APIs", "Postman"]
  },
  {
    title: "Concepts",
    skills: ["DSA", "OOP", "DBMS", "OS", "System Design"]
  }
];

const Skills = () => {
  return (
    <section id="skills" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Technical Skills</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-6 shadow-md">
              <h3 className="text-xl font-semibold mb-4 text-blue-600">{category.title}</h3>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill, skillIndex) => (
                  <span
                    key={skillIndex}
                    className="px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 bg-blue-50 rounded-lg p-8">
          <h3 className="text-2xl font-bold mb-6 text-center">Achievements</h3>
          <ul className="space-y-4 max-w-2xl mx-auto">
            <li className="flex items-center space-x-3">
              <span className="text-blue-600">•</span>
              <span>Global Rank 2266 in TCS CodeVita Season 11</span>
            </li>
            <li className="flex items-center space-x-3">
              <span className="text-blue-600">•</span>
              <span>Solved 250+ LeetCode problems, maintained 179-day streak</span>
            </li>
            <li className="flex items-center space-x-3">
              <span className="text-blue-600">•</span>
              <span>Selected for Prescreening Round – Smart India Hackathon</span>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default Skills;